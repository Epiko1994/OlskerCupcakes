create view Orders as
select `Cupcake`.`orders`.`order_id`                                                                              AS `Order ID`,
       `Cupcake`.`user`.`email`                                                                                   AS `Email`,
       concat(`Cupcake`.`topping`.`topping_name`, ' + ',
              `Cupcake`.`base`.`base_name`)                                                                       AS `Cupcake`,
       `Cupcake`.`order_lines`.`amount`                                                                           AS `Amount`,
       ((`Cupcake`.`topping`.`topping_price` + `Cupcake`.`base`.`base_price`) *
        `Cupcake`.`order_lines`.`amount`)                                                                         AS `Total`
from ((((`Cupcake`.`order_lines` join `Cupcake`.`orders` on ((`Cupcake`.`order_lines`.`order_id` = `Cupcake`.`orders`.`order_id`))) join `Cupcake`.`user` on ((`Cupcake`.`orders`.`user_id` = `Cupcake`.`user`.`user_id`))) join `Cupcake`.`topping` on ((
    `Cupcake`.`order_lines`.`topping_id` = `Cupcake`.`topping`.`topping_id`)))
       join `Cupcake`.`base` on ((`Cupcake`.`order_lines`.`base_id` = `Cupcake`.`base`.`base_id`)));

